from annoy import AnnoyIndex
import random
f = 40
t = AnnoyIndex(f,metric="angular")
for i in xrange(1000):
    v = [random.gauss(0, 1) for z in xrange(f)]
    t.add_item(i, v)
t.build(10) 
t.save('test.ann')
