#coding=utf-8
#coding:utf-8
#-*- coding:utf-8 -*-
 
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_wine
wine = load_wine()
Xtrain, Xtest, Ytrain, Ytest = train_test_split(wine.data,wine.target,test_size=0.3)
#print (X,y)
 
#默认参数
#Accuracy : 0.9856
#AUC Score (Train): 0.862264
gbm1 = GradientBoostingClassifier( n_estimators=500,max_depth=10,max_features='sqrt', random_state=10)
gbm1.fit(Xtrain,Ytrain)
print "gbdt1",gbm1.score(Xtest,Ytest)
 
 
