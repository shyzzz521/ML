
# -*- encoding:utf-8 -*-
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier

from sklearn.datasets import load_wine
wine = load_wine()
Xtrain, Xtest, Ytrain, Ytest = train_test_split(wine.data,wine.target,test_size=0.3)

bdt1 = AdaBoostClassifier(DecisionTreeClassifier(max_depth=2, min_samples_split=20, min_samples_leaf=5),n_estimators=50)
bdt1.fit(Xtrain, Ytrain)
print "bdt1",bdt1.score(Xtest,Ytest)

#分类器越多效果越好
bdt2 = AdaBoostClassifier(DecisionTreeClassifier(max_depth=2, min_samples_split=20, min_samples_leaf=5),n_estimators=300)
bdt2.fit(Xtrain, Ytrain)
print  "bdt2",bdt2.score(Xtest,Ytest)

